import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../model/Customer';
@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(private httpClient:HttpClient) { 
    
  }

  getStock()
  {
    console.log("test call");
    return this.httpClient.get<Customer[]>('http://localhost:8080/customers');
  }
}
