import { Component, OnInit , ViewChild} from '@angular/core';
import { Customer } from '../model/Customer';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit {
  stock:Customer [] = [];
  cacheStock: Customer[] = [];


  
  constructor(private httpClientService: HttpClientService) { 
  }

  ngOnInit() {
    this.httpClientService.getStock().subscribe(
      (response) => {
        this.stock = response;
        this.cacheStock = response;
      }
    );
  }

}
