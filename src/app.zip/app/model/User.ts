export class User {
    id: number;
    name: string;
    phone: string;
    status: boolean;
    constructor(public _id: number, public _name: string, public _phone: string, public _status: boolean) {
        this.id = _id;
        this.name = _name;
        this.phone = _phone;
        this.status = _status;
    }
}