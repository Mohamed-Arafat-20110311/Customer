import  { User } from './User';

export class Customer {
    country: string;
    users: User[];
    constructor(private _country: string, public _users: User[]) {
        this.country = _country;
        this.users = _users;
    }
}